# Kwikshift Frontend - Truehost Deployment

## Upload Steps
1. Upload kwikshift-frontend-production.zip to public_html
   via cPanel File Manager
2. Extract directly into public_html
3. Confirm .htaccess is in public_html root

## Permissions (via cPanel File Manager or SSH)
chmod 755 public_html
chmod -R 777 public_html/storage

## Important: Truehost Outbound Port
This site connects to Railway MySQL on port 28747.
If you get DB connection errors, contact Truehost support
and request outbound TCP port 28747 to be whitelisted for
the IP: junction.proxy.rlwy.net

## Verify After Deploy
- https://www.kwikshiftmovers.co.ke loads
- Quote form submits -> check Railway DB quote_requests table
- Contact form submits -> check Railway DB messages table
- Gallery loads images from Cloudinary
- FAQs load from Railway DB
- Careers page shows open jobs

## Troubleshooting
- 500 error: chmod -R 777 storage/
- Blank page: check PHP error log in cPanel -> Logs
- DB refused: Truehost port 28747 not whitelisted
- CORS error: confirm admin panel allows
  https://www.kwikshiftmovers.co.ke in CORS config
- Images broken: check AppConfig.resolvImageUrl() in config.js
